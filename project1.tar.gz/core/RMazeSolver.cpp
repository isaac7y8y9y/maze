#include "RMazeSolver.hpp"
#include <ics46/factory/DynamicFactory.hpp>
#include "Direction.hpp"
#include <iostream>
#include <vector>
#include <random>

ICS46_DYNAMIC_FACTORY_REGISTER(MazeSolver, RMazeSolver, "RSolver(Required)")

RMazeSolver::RMazeSolver(){}
void RMazeSolver::solveMaze(const Maze& maze, MazeSolution& mazeSolution)
{

	RMazeSolver::letssolve(maze, mazeSolution);

}

void RMazeSolver::letssolve(const Maze& maze, MazeSolution& mazeSolution)
{

	if(mazeSolution.isComplete()==1 && mazeSolution.getCurrentCell()==mazeSolution.getEndingCell())
	{
		//std::cout << "Maze Done" << std::endl;
		return;
	}
	std::vector<Direction> available;
	std::pair<int, int> coord=mazeSolution.getCurrentCell();
	available = RMazeSolver::gps(maze, mazeSolution, available, coord);
	//std::cout << coord.first << " : " << coord.second << std::endl;
	if(available.size()==0)
	{
		banned.push_back(coord);
		if(mazeSolution.getCurrentCell()==mazeSolution.getEndingCell() && mazeSolution.isComplete()==1)
		{
			//std::cout << "Maze Done" << std::endl;
			return;
		}
		else
		{
			//std::cout << "Dead End" << std::endl;

			mazeSolution.backUp();
			
			letssolve(maze, mazeSolution);
		}

	}

	
	else 
	{
		//std::cout << "Find Path" << std::endl;
		shuffle(available.begin(), available.end(), sided);
		mazeSolution.extend(available[0]);
		letssolve(maze, mazeSolution);
		
	}
}

RMazeSolver::~RMazeSolver(){}


std::vector<Direction> RMazeSolver::gps(const Maze& maze, MazeSolution& mazeSolution, std::vector<Direction> available, std::pair<int, int> coord)
{
	int tx = coord.first;
	int ty = coord.second;
	std::vector<std::pair<int, int>> visited=mazeSolution.getCells();
	for(int i =0; i<ways.size(); ++i)
	{
		//up
		if(ways[i]==Direction::up && ty >0 && maze.wallExists(tx, ty, ways[i])==0
			&& find(banned.begin(), banned.end(), std::make_pair(tx, ty-1))==banned.end()
			&&find(visited.begin(), visited.end(), std::make_pair(tx, ty-1))==visited.end())
		{
			available.push_back(ways[i]);
		}
		else if(ways[i]==Direction::right && tx < maze.getWidth()-1 && maze.wallExists(tx, ty, ways[i])==0
			&& find(banned.begin(), banned.end(), std::make_pair(tx+1, ty))==banned.end()
			&&find(visited.begin(), visited.end(), std::make_pair(tx+1, ty))==visited.end())
		{
			available.push_back(ways[i]);
		}
		else if(ways[i]==Direction::down && ty < maze.getHeight()-1 && maze.wallExists(tx, ty, ways[i])==0
			&& find(banned.begin(), banned.end(), std::make_pair(tx, ty+1))==banned.end()
			&&find(visited.begin(), visited.end(), std::make_pair(tx, ty+1))==visited.end())
		{
			available.push_back(ways[i]);
		}
		else if(ways[i]==Direction::left && tx > 0 && maze.wallExists(tx, ty, ways[i])==0
			&& find(banned.begin(), banned.end(), std::make_pair(tx-1, ty))==banned.end()
			&&find(visited.begin(), visited.end(), std::make_pair(tx-1, ty))==visited.end())
		{
			available.push_back(ways[i]);
		}
	}
	return available;
}