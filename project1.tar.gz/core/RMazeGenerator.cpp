#include "RMazeGenerator.hpp"
#include "Direction.hpp"
#include <ics46/factory/DynamicFactory.hpp>
#include <random>
#include <iostream>
#include <algorithm>
#include <utility>
#include <vector>
#include <MazeVerifier.hpp>
ICS46_DYNAMIC_FACTORY_REGISTER(MazeGenerator, RMazeGenerator, "RMaze (Required)");
RMazeGenerator::RMazeGenerator()
{
}

void RMazeGenerator::generateMaze(Maze& maze)
{
	int x=0;
	int y=0;
	std::random_device scramble;
	std::default_random_engine sided{scramble()};
	std::vector<std::vector<bool>>visited(maze.getWidth(), std::vector<bool>(maze.getHeight(), false));
    maze.addAllWalls();
    digMaze(maze, sided, visited, x, y);
}
void RMazeGenerator::digMaze(Maze& maze, std::default_random_engine sided, std::vector<std::vector<bool>> & visited, int x, int y)
{	
	std::vector<Direction> available;

	
	if(visited[x][y]==false)
	{ 
		visited[x][y]=true;
	}

	available = RMazeGenerator::breakwhere(x, y, maze, available, visited);

	if(available.size()==0)
	{
		return;
	}
	else
	{
		shuffle(available.begin(), available.end(), sided);
		int i;
		for(i = 0; i < available.size(); ++i)
		{
			if(available[i]==Direction::up && y>0 && maze.wallExists(x, y, available[i])==1
				&& visited[x][y-1]==false)
			{
				maze.removeWall(x, y, available[i]);
				int ny=y-1;
				digMaze(maze, sided, visited, x, ny);
				//break;
			}
			else if(available[i]==Direction::right && x<maze.getWidth()-1 && maze.wallExists(x, y, available[i])==1
				&& visited[x+1][y]==false)
			{
				maze.removeWall(x, y, available[i]);
				int nx=x+1;
				digMaze(maze, sided, visited, nx, y);
				//break;
			}
			else if(available[i]==Direction::down && y<maze.getHeight()-1 && maze.wallExists(x, y, available[i])==1
				&& visited[x][y+1]==false)
			{
				maze.removeWall(x, y, available[i]);
				int ny = y+1;
				digMaze(maze, sided, visited, x, ny);
				//break;
			}
			else if(available[i]==Direction::left && x>0 && maze.wallExists(x, y, available[i])==1
				&& visited[x-1][y]==false)
			{
				maze.removeWall(x, y, available[i]);
				int nx=x-1;
				digMaze(maze, sided, visited, nx, y);
				//break;
			}
		}
	}
	
	
}

std::vector<Direction> RMazeGenerator::breakwhere(int x, int y, Maze& maze, std::vector<Direction> available, std::vector<std::vector<bool>> &visited)
{
	int i;
	
	for(i=0; i<4; ++i)
	{
		if(ways[i]==Direction::up && y>0 && maze.wallExists(x, y, ways[i])==1 
			&& visited[x][y-1]==false)
		{
			available.push_back(ways[i]);
		}
		else if(ways[i]==Direction::right && x<maze.getWidth()-1 && maze.wallExists(x, y, ways[i])==1 
			&& visited[x+1][y]==false)
		{
			available.push_back(ways[i]);
		}
		else if(ways[i]==Direction::down && y<maze.getHeight()-1 && maze.wallExists(x, y, ways[i])==1 
			&& visited[x][y+1]==false)
		{
			available.push_back(ways[i]);

		}
		else if(ways[i]==Direction::left && x>0 && maze.wallExists(x, y, ways[i])==1 
			&& visited[x-1][y]==false)
		{
			available.push_back(ways[i]);
		}
	}
	return available;
}
RMazeGenerator::~RMazeGenerator()
{
}
