#ifndef RMAZESOLVER_HPP
#define RMAZESOLVER_HPP
#include "MazeSolver.hpp"
#include "Maze.hpp"
#include "MazeSolution.hpp"
#include <vector>
#include <random>
#include "Direction.hpp"

class RMazeSolver: public MazeSolver
{
public:
	RMazeSolver();
	virtual void solveMaze(const Maze& maze, MazeSolution& mazeSolution);
	void letssolve(const Maze& maze, MazeSolution& mazeSolution);
	~RMazeSolver();
private:
	std::vector<Direction> ways{Direction::up, Direction::right, Direction::down, Direction::left};
	std::vector<std::pair<int, int>> banned;
	std::random_device scramble;
	std::default_random_engine sided{scramble()};
	//int call=0;
	std::vector<Direction> gps(const Maze& maze, MazeSolution& mazeSolution, std::vector<Direction> available, std::pair<int, int> coord);
};
#endif //RMAZESOLVER_HPP
