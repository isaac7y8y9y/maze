#ifndef RMAZEGENERATOR_HPP
#define RMAZEGENERATOR_HPP

#include "MazeGenerator.hpp"
#include "Maze.hpp"
#include <random>
#include <iostream>
#include <vector>
#include "Direction.hpp"
class RMazeGenerator:public MazeGenerator
{
public:
    RMazeGenerator();
    virtual void generateMaze(Maze& maze);
    void digMaze(Maze& maze, std::default_random_engine sided, std::vector<std::vector<bool>> & visited, int x, int y);
    ~RMazeGenerator();
private:

    std::vector<Direction> ways{Direction::up, Direction::right, Direction::down, Direction::left};

    std::vector<Direction> breakwhere(int x, int y, Maze& maze, std::vector<Direction> available, std::vector<std::vector<bool>> & visited);

};

#endif //RMAZEGENERATOR_HPP
